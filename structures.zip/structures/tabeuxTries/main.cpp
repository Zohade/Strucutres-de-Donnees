#include <iostream>
#include<stdlib.h>

/*
 ***************************************************************************************************
    Représentation enn interne d'un ensemble en utlisant des tableaux triés
 ***************************************************************************************************
        - Convention de représentation
        ------------------------------
            * Un tableau représente toujours un ensemble trié

                -le tableau représente un ensemble
 */
using namespace std;

static const int NMax=1000; // Le nombre maximal d’élé ments
 typedef struct MonEnsemble MonEnsemble ;
 struct MonEnsemble {
     int set[NMax] ; // le tableau contenant E
     int n ; // le nombre d’élé ments de E
 } ;
 /*
  taille du tableau
  */
 void initilialize(MonEnsemble * toto)
 {

     toto->n=0;

 }

 /* Retourne l ’élé ment de position pos
 verifier d'abord si pos est inférieur à la taille du tableau
 */
 int get ( MonEnsemble toto , int pos )
 {
     if(pos<toto.n)
     {
        return toto.set[pos];
     }
     else
     {
        cout<<"Debordement de capacite";
        exit(1);
     }
 }
 /* Ajoute l ’élé ment elem dans le tableau en le maintenant trié.
        - n est la taille du tableau
        - tous les elements du tableau sont
 =================================================================================================
 Problemes à gérer
 =================================================================================================

    1- Trouver j, l'index d'insertion  de elem (sa position)
    2- Decaler d'un pas vers la droite tous les elements de toto supérieurs à elem
    3- Inserer elem

 */
 /*
  *Probleme 1
      @pre
        toto est un ensemble trié
        elem n"est pas dans toto
      @post
        toto reste inchangé
      @result
        returne j tel que toto.set[0...j[<elem<toto.set[j...n-1]
  */
 int retourneJ(MonEnsemble toto, int elem)
 {
    int j=0;
    while(j<toto.n && toto.set[j]<elem)
    {
        j++;
    }
    return j;
 }
 /*
  *Probleme 2 && 3
      @pre
        toto est un ensemble trié
        0<=j<n<=|A|
      @post
        tous les elements de toto.set de j à n-1 sont décalés d'un pas vers la droite
      @result
        returne j tel que toto.set[0...j[<elem<toto.set[j...n-1]
  */
 void decaledroit(MonEnsemble &toto, int j, int n)
 {
     int i=n;
     while(i>j-1)
     {
         toto.set[i]=toto.set[i-1];
         i--;
     }
     toto.n+=1;
 }

 void add ( MonEnsemble & toto , int elem)
 {
     //Etape 1 : trouver j
      int j=retourneJ(toto,elem);
     //Etape 2 : decaler à droite;
      decaledroit(toto,j,toto.n);
     //Etape 3: inserer j
      toto.set[j]=elem;
 }

 /* Remplace l’élément de la position pos par elem et
 retourne l’élément initiale de cette position
 @pre
   * toto est une reference vers un ensemble
   pos est inférieure à n
  @post
   toto change en prenant l'element elem à la position pos
  @return
   retourne l'element à la position pos avant remplacement
===================================================================================================
    Probleme à régler
==================================================================================================
    1- chercher la position d'insertion de elem
    2- Decaler vers à la gauche le sous tableau tab[i...j]
    3-Decaler vers à la droite le sous tableau tab[i...j]
    4- inserer elem
 */
 //P1 déjà fait
 //P2
 void decalegauche(MonEnsemble &toto,int j, int n)
 {
     int i=j+1;
     while(i<n)
     {
         toto.set[i-1]=toto.set[i];
         i++;
     }
 }
 //P3 deja fait
 int set(MonEnsemble &toto , int elem , int pos)
 {
     //Etape 1 : Sauvegarder l'element à remplacer
     int sortie=toto.set[pos];
     //Etape 2 : trouver l'index d'insertion
     int j=retourneJ(toto,elem);
     //Etape 3 : decaler d'un pas vers la droite le sous tableau tab[pos...j]
     if(pos>j)
     {
         decaledroit(toto,j,pos);
         toto.set[j]=elem;
     }
     else if(j<pos)
     {
         decalegauche(toto,pos+1,j);
         toto.set[j]=elem;
     }
     //Etape 4 : decaler d'un pas dans la gauche
     else {toto.set[pos]=elem;}

     return sortie;
 }

 /*int set ( MonEnsemble &toto , int elem , int pos )
 {
     //chap1: sauvegarder l'element à la position pos
     int sortie=toto.set[pos];
    //verifier si taille est respectée
     if(pos<toto.n)
     {
         //changer la variable
         int j=retourneJ(toto,elem);
         if(pos<j)
         {
             for(int i=pos;i<j && i<toto.n;i++)
             {
                 toto.set[i]=toto.set[i+1];
             }
              add(toto,elem);
         }
         else if(pos>j)
         {
            decale(toto,j,toto.n);
            toto.set[j]=elem;
         }
         else
         {
             toto.set[pos]=elem;
         }


             return sortie;
     }else
     {
         cout<<"Debordement de capacite";
         exit(1);
     }
 }*/

 /* Supprime l ’élé ment de position pos et le renvoie ,
 puis repositionne les autres élé ments
  @pre
    toto est un ensemble
    pos est inferieur à  la taille du tableau
  @post
    toto change, perd element position pos
  @return
    l'element à la position supprimée
*/
int remove ( MonEnsemble * toto , int pos )
{
    //chap1: vérifie que pos est inférieur à n
    if(pos<toto->n)
    {
    //chap2: recupère l'element dans une variable
        int retour= toto->set[pos];
        for(int i=pos;i<toto->n;i++)
        {
            //ecrase l'element par
            toto->set[i]=toto->set[i+1];
        }
        toto->n=toto->n-1;
        return retour;

    }
}
/* Renvoie l’union des ensembles A et B
    faire une fusion de A et B, en prenant à chaque fois le minimum des tableaux. si l'un des tableau prend fin,
    on recopie le reste du second tableau.
 @pre
    A et B: sont des ensembles.
 @post
    verifie q'un element ne figure pas deux fois dans l'union
 @return
    un ensemble contenant l'union des elements

*/

MonEnsemble unnion ( MonEnsemble A , MonEnsemble B)
{
}

/* Renvoie les élé ments de A qui ne sont pas dans B
 *@pre
    A et B sont deux ensembles.
  @post
    A et B n'ont pas changé.
  @return
    un ensemble
*/

/* MonEnsemble diff ( MonEnsemble A , MonEnsemble B)
 {
     MonEnsemble C;
     initilialize(&C);
     int var=0;
     int elem;
    //une boucle qui parcours A
     for(int i=0;i<A.n;i++)
     {
         //une boucle qui parcours B
         for(int j=0;j<B.n;j++)
         {
             //verifie si l'element de A n'est pas dans B
             if(A.set[i]!=B.set[j])
             {
                var=1;
                elem=B.set[j];
             }/*else
             {
                 var=0;

             }

         }
         /*envoie la valeur de A qui n'est pas dans B dans C
            verifie si l'element n'est pas encore dans le tableau

         if(var==1)
         {
             for(int k=0;k<C.n;k++)
             {
                 if(elem!=C.set[k])
                 {
                     var=2;
                 }
             }
             if(var==2)
             {
               add(&C,elem,0);
             }

         }
     }
     return C;
 }

 /* Renvoie le nombre d’élé ments dans l’ ensemble

   @return
     la taille

*/
 int size ( MonEnsemble toto )
 {

     return toto.n;
 }
 /* Renvoie vrai si l’ ensemble est vide */

 bool isEmpty ( MonEnsemble toto )
 {
     return{(toto.n==0)?true:false};
 }

 /* Renvoie le premier élé ment de l’ ensemble */

 int getFirst ( MonEnsemble toto )
 {
     return toto.set[0];
 }

 /* Renvoie le dernier élé ment de l’ ensemble */

 int getLast ( MonEnsemble toto , int elem , int pos )
 {
     return toto.set[toto.n-1];
 }

 /* Mais aussi : addLast , addFirst , removeLast ,
removeFirst ... */

/*
 affiche l'ensemble

 @pre
   toto est un ensemble
 @post
   toto reste inchangé
   affiche les élements de l'ensemble toto
 @return
*/
void affiche(MonEnsemble toto)
{
    int i=0;
    while(i<toto.n)
    {
        cout<<"set["<<i<<"]= "<<toto.set[i]<<endl;
        i++;
    }
}

int main(){
 MonEnsemble A;
 initilialize(&A);
 add(A,2);
 add(A,9);
 add(A,6);
 add(A,8);
 add(A,1);
 add(A,0);
 add(A,12);
 cout<<"Tableau avant set\n";
 affiche(A);
 cout<<"element  a la pos \n";
 cout<<set(A,7,3)<<endl;
 cout<<"Tableau apres set\n";

 affiche(A);



 return 0;
}

#include <iostream>
#include <cstdlib>
using namespace std;

struct Node
{
    int val;
    Node *suivant;
};

struct LinkedList
{
    int id;
    int taille;
    Node *tete;
};




/** Détermine le nombre d ’éléments de la liste
@pre list != null
@post la liste reste inchangée
@return n = | list | , le nombre d ’élément dans la liste
*/

int taille ( LinkedList list )
{
    if(&list!=NULL)
    return list.taille;
    cout<<"La liste n\'existe pas \n";
}

/** Détermine si la liste est vide
@pre list != null
@post list reste inchangée
@result 1 si list == {} , 0 sinon
*/
int estVide ( LinkedList list )
{
    if(&list!=NULL)
        return{(list.taille==0)?1:0};
}

/** Ajoute la valeur val au début de la liste
    @pre list != NULL
    @post list devient list + Cellule ( val ) à la premi è re position
    @result -

STEP1
    créer un new Node et ajouter val;
STEP2
    affecter à new le pointeur du premier element de la liste
STEP3
    positionner le premier element de la liste à new
STEP4
    ajouter +1 à la taille;

*/
void ajouteDebut ( LinkedList * list , int valeur )
{
        Node * ajout= new Node;
        if(list==NULL || ajout==NULL )
        {
            exit(EXIT_FAILURE);
        }
        ajout->val=valeur;
        ajout->suivant=list->tete;
        list->tete=ajout;
        list->taille+=1;

}

/** Ajoute la valeur val à la fin de la liste
@pre list != NULL
@post list devient list + Cellule ( val ) à la derni è re position
@result -

STEP1:
    creer un new de Node et ajouter var
STEP2:
    positionner le new à la fin de la liste
STEP3:
    affecter le suivant du  dernier element de la liste à new
STEP4:
    affecter le suivant de new à NULL et ajouter +1 à la taille de la liste
*/
void ajouteFin ( LinkedList * list , int valeur )
{
    Node * ajout = new Node;
    if(list==NULL || ajout==NULL)
    {
        exit(EXIT_FAILURE);
    }
    ajout->val=valeur;
    int i = 1 ;
    Node * cur = list->tete;
    while (i < list->taille)
    {
        /* code */
        cur = cur->suivant;
        i++;
    }
    cur->suivant=ajout;
    ajout->suivant=NULL;
    list->taille+=1;
}


/** Ajoute la valeur val à la position n de la liste
@pre list != NULL
0 <= n <= list -> taille

@post liste devient list + Node ( val ) à
la position n de la liste
@result -
*/
void ajoutePosition ( LinkedList * list , int val , int n )
{
    /** Etape 1: Créer un nouvelle cellule et
               ajouter val à l'intérieur*/
    Node *newNode = new Node;
    newNode -> val = val;

    /** Etape 2: Positionner la cellule "cur"
                à la position n -1 */
    int i = 0 ;
    Node * cur = list->tete;
    while (i < n )
    {
        /** code */
        cur = cur->suivant;
        i++;

    }

    /** Etape 3: sauvegarder le reste de la liste*/
    Node * reste = cur->suivant;
    /** Etape 4: linker la nouvelle cellule*/
    cur->suivant = newNode;
    newNode->suivant = reste;
    /** Etape 4: Incrémenter la taille de la liste*/
    list->taille+=1;

}
/** Supprime la première Node de la liste list
@pre list != NULL
@post list devient list ’ qui est la list sans son premier
élément
@result -

STEP1:
    Verfier que le premier element de la liste est non null;
STEP2:
    recuperer le premier element dans une variable
STEP3:
    pointer la tête de la liste sur l'element suivant le premier
STEP4:
    supprimer l'element suivant avec la fonction free et soustraire
    1 à la taille de la liste

*/
void supprimeDebut ( LinkedList * list )
{
    if (list == NULL)
    {
        exit(EXIT_FAILURE);
    }

    if (list->tete != NULL)
    {
        Node *aSupprimer = list->tete;
        list->tete = list->tete->suivant;
        delete aSupprimer;
        list->taille-=1;
    }
}

/** Supprime la dernière Cellule de la liste list
@pre list != NULL
@post list devient list ’ qui est la list sans son dernier élément
@result -

STEP1:
    creer un curseur pour parcourir la liste et atteindre son dernier element

STEP2:
    creer une nouvelle Node et recuperer le dernier element
STEP3:
    pointer le suivant de l'avant dernier element vers NULL
STEP4:
    supprimer le dernier element et diminuer la taille de 1;

*/
void supprimeFin ( LinkedList * list )
{
    if(list==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(list->taille>1)
    {
        Node* cur=list->tete;
        int i=0;
        while (i < list->taille-2)
        {
            /* code */
            cur = cur->suivant;
            i++;
        }
        Node * suppri=cur->suivant;
        cur->suivant=NULL;
        delete suppri;
        list->taille-=1;

    }
    else if(list->taille==1)
    {
        supprimeDebut(list);
    }

}

/** Supprime la Cellule de la position pos dans la liste list
@pre list != NULL
@post list devient list ’ qui est la list sans son pos i è me é l é ment
@result -


STEP1:
    creer un curseur qui parcourt la liste jusqu'a atteindre pos
STEP2:
    creer une variable qui stocke la valeur à la position pos
STEP3:
    pointer le suivant de l'element pos-1 à l'element pos+1
STEP4:
    supprimer l'element pos et diminuer la taille
*/
void supprimePosition ( LinkedList * list , int pos )
{
    if(list==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(list->taille>0)
    {
        if(pos>0)
        {
            Node * cur=list->tete;
            int i=0;
            while(i<pos-1)
            {
                cur=cur->suivant;
                i++;
            }
            Node * old=cur->suivant;
            cur->suivant=old->suivant;
            free(old);
            list->taille-=1;
        }
        else if(pos==0)
        {
            supprimeDebut(list);
        }

    }
}

/** Donne la première Cellule de la liste list
@pre list != NULL
@post list reste inchang é e
@result donne la premi è re Cellule de la liste
*/
Node * donnePremier ( LinkedList * list )
{
    if(list==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(list->taille>0)
    {
        return list->tete;
    }
}

/** Donne la dernière Cellule de la liste list
@pre list != NULL
@post list reste inchangée
@result Donne la premi è re Cellule de la liste .
*/
Node * donneDernier ( LinkedList * list )
{
    if(list==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(list->taille>0)
    {
        Node* cur=list->tete;
        int i=0;
        while (i < list->taille-2)
        {
            /** code */
            cur = cur->suivant;
            i++;
        }
        return cur->suivant;
        delete cur;
    }
}

/** Donne la Cellule à la position pos de la liste list
@pre list != NULL
@post list reste inchangée
@result donne la Cellule à la position pos de la liste list
*/
Node * donnePosition ( LinkedList * list, int pos )
{
    if(list==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(list->taille>0)
    {
        Node * cur=list->tete;
        int i=0;
        while (i < pos)
        {
            /** code */
            cur = cur->suivant;
            i++;
        }
        return cur;
        delete cur;

    }
}

/** Initialise la liste list en lui attribuant le numéro number
@pre list != NULL
@post list est initialisée et porte le numéro number
@result -
*/
void initList ( LinkedList * list , int number )
{

        if(list==NULL)
        {
            exit(EXIT_FAILURE);
        }
        list->taille=0;
        list->id=number;

}

/** Affichage de la liste sous le format
Node [0] = valeur0
Node [1] = valeur1
...
Node [ n ] = valeurn
@pre list != NULL
@post list reste inchang ée , mais l’affichage selon le format sp é cifi é e
@result -
*/
void afficheList ( LinkedList list )
{
    if (&list == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Node *actuel = list.tete;
    while (actuel != NULL)
    {
        cout<<actuel->val<<"-> ";
        actuel = actuel->suivant;

    }
    cout<<"NULL\n";
    delete actuel;
}

/** Destruction de la liste
@pre list != NULL
@post la liste est d é truite , y compris toutes ces Cellules
@return -

STEP1:
    supprimer tous les elements de la liste, en partant du debut
STEP2:
    supprimer la liste en libérant la mémoire allouée à la liste
*/
void detruitList ( LinkedList * list )
{
    if (&list == NULL)
    {
        exit(EXIT_FAILURE);
    }
    while(list->taille>0)
    {
        supprimeDebut(list);
    }
    delete list;
}
/** Union de deux listes
 @pre
    A et B sont deux listes et n est id de la liste union;
 @post
        C vaut A+B;
        C a pour taille A->taille + B->taille
        C->tete=A->tete
 @return
    C
=========================================================================================
                            STEP
=========================================================================================

STEP1:
    Creation de la liste C en initialisant l'identifiant
    à n;
STEP2:
    verifier que les listes A B et C sont non vides;
STEP3:
    Copie des elements de A dans C avec C->tete=A->tete;
STEP4:
   copie les elements de B dans C
 */
LinkedList * unnion(LinkedList A, LinkedList B, int n)
{
    ///STEP1
    LinkedList *C=new LinkedList;
    initList(C,n);
    ///STEP2
    if(C==NULL || &A==NULL || &B==NULL)
    {
        exit(EXIT_FAILURE);
    }

    ///STEP3
    Node* cur=A.tete;
    while(cur!=NULL)
    {
        ajouteDebut(C,cur->val);
        cur=cur->suivant;
    }
    delete cur;
    Node * actuel=B.tete;
    while(actuel!=NULL)
    {
        ajouteFin(C,actuel->val);
        actuel=actuel->suivant;
    }
    delete actuel;
    return C;
}


int main()
{
    LinkedList * malist= new LinkedList;
    LinkedList * salist= new LinkedList;
    initList(malist,1);
    initList(salist,2);
    ajouteDebut(malist, 10);
    ajouteDebut(salist,12);
    afficheList(*malist);
    afficheList(*salist);
    LinkedList *C= unnion(*malist, *salist, 3);
    afficheList(*C);





    return EXIT_SUCCESS;
}

#include "ensemble.h"

using namespace std;

int main()
{
    int tab[]={0,2,4,6,8,10};
    cout<<"TEST SUR LES FONCTIONNALITES DE LA CLASSE \n";
    cout<<"creation d'un objet\n";
    Ensemble A(tab,6);
    A.affiche2();
    cout<<endl<<"creation d'un second objet B\n";
    Ensemble B=A;
    B.affiche2();
    cout<<endl;
    cout<<B.set(3,3);
    cout<<endl;
    B.affiche2();
    cout<<endl;
    Ensemble C = A.unnion(B);
    C.affiche2();
    return 0;
}

#ifndef ENSEMBLE_H
#define ENSEMBLE_H

#include <iostream>

#define NMAX 1000 //decalaration de NMAX

class Ensemble
{
 private:
    ///declaration des attributs de EnsembleTrie
    int tab[NMAX];
    int n;///taille réelle de la table

 public:
    /** *********************************************************************************
                Constructeur & destructeurs
     ************************************************************************************/
        ///constructeur sans parametre
         Ensemble();
         /** contructeur prenant en parametre un tableau
            */
         Ensemble(int a[], int taille);
            /**
             * Construteur par copie.
             */
         Ensemble(const Ensemble& A);
         /// destructeur
         virtual ~Ensemble();
     /** *****************************************************************************
          modifier les attributs
     *******************************************************************************/

         ///Modifie la valeur de la taille du tableau
         void setN(int taille);
         ///Modifie la valeur d'un element du tableau
         void setTab(int i, int pos);
         ///Acceder aux attributs
         int getN();/// accede à la taille
         int getTab(int pos);/// accede à un element du tableau
         /// permet d'afficher les ensembles
         void affiche();
         void affiche2 ();
         int trouverJ(int elem);
         void decaleDroite(int a, int b);
         void add (int elem);
         void decaleGauche(int a, int b);
         int set (int elem , int pos );
         Ensemble remove (int pos ) ;
         bool notin(int elem) ;
         Ensemble unnion( Ensemble B);
         Ensemble diff ( Ensemble B ) ;
         int size ();
         bool isEmpty ();
         int getFirst () ;
         int getLast ();
















};
#endif // ENSEMBLE_H

#include "ensemble.h"

using namespace std;

/// CONSTRUCTEURS
/**
 *construecteur par defaut initialisant la taille du tableau à 0
  soit n=0
 */

Ensemble::Ensemble(){n=0;}
/**
@pre
  l'ensemble est vide
  taille est inférieure à NMAX
@post
      l'ensemble est crée
@return -
*/
Ensemble::Ensemble(int a[], int taille)
{
    if(taille<=NMAX)
    {
        n=taille;
         int i=0;
       while(i<n)
       {
           tab[i]=a[i];
           i++;
       }
    }
    else
    {
        cout<<"Taille maxiamle depassee\n ";
    }
}
/**
 * Construteur par copie.
 @pre
    A est un ensemnble;
 @post
    la taille de A est donnée à this->n;
    les elements de A sont tous copiés à this->tab;
 @return -
 */
Ensemble::Ensemble(const Ensemble& A)
{
    n=A.n;
    int i=0;
    while(i<n)
    {
        tab[i]=A.tab[i];
        i++;
    }
}


/** Destructeur
 *detruit un element et affiche un message
 */
Ensemble::~Ensemble()
{
    cout<<"Mort d\'un objet\n";
}

///MODIFICATEUR

/**
 *Modifie l'attribut N, représentant la taille du tableau
 @pre -
 @post this->n=taille
 @return -
 */
void Ensemble::setN(int taille)
{
    n=taille;
}

/**
 *Permet d'acceder à la taille du tableau
 @pre -
 @post -
 @return
       la taille n;
 */

int Ensemble::getN()
{
    return n;
}
/**
 *Permet d'acceder à un element du tableau
 @pre
    pos est inférieure à la taille du tableau
  @post -
  @return
    tab[pos];
 */
int Ensemble::getTab(int pos)
{
    if( pos >=0 && pos<n) return tab[pos];
    cout<<"Taille depassee\n";
}
/** affiche l'ensemble toto
@pre
     -
@post
    affiche les éléments de l'ensemble this->tab
@return
    -
*/
void Ensemble::affiche()
{
    int i = 0 ;
    cout << "Votre ensemble est :\n" ;
    while (i <n)
    {
        cout << "\tset[" << i << "] = " << tab[i] << "\n" ;
        i ++ ;
    }
}
void Ensemble::affiche2 ()
{
    int i = 0 ;
    cout << "[" ;
    while (i < n-1) cout << tab[i ++] << "; " ;
    cout << tab[i] << "]" ;
}

/** Ajoute l ’élément elem dans le tableau en le maintenant trié
@pre
      -  n est le nombre réel d'éléments de toto
      -  tous les éléments de this->tab sont distincts 2 à 2
      -  l'ensemble est trié en ordre croissant
  *  elem n'est pas dans this->tab
@post
    l'élément elem est ajouté dans this->tab de manière que this->tab reste trié
@result
    -
*/
/**
Division en sous-problèmes
--------------------------
SP1 : TrouverJ, l'index d'insertion de elem
SP2 : Décaler d'un pas vers la droite tous les éléments de toto.set[j..n-1] (supérieur à elem)
SP3 : Insérer elem
*/
/** SP1 : trouverJ, l'index d'insertion de elem
@pre
    this->tab est un ensemble trié
    elem n'est pas dans this->tab
@post
    this->tab reste inchangé
@result
    retourne j tel que this->tab[0..j[ < elem < this->tab[j..n-1]
*/
int Ensemble::trouverJ(int elem)
{
    int j = 0 ;
    while (j < n && tab[j] < elem) j ++ ;
    return j ;
}
/** SP2 : Décaler d'un pas vers la droite tous les éléments du tableau A d'un pas
@pre
    A est un tableau trié
    0 <= a < b < NMAX
@post
    tous les éléments de A[a..b] sont décalés d'un pas vers la droite
@result
    -
*/
void Ensemble::decaleDroite(int a, int b)
{
    int i = b ;
    while (i >= a)
    {
        tab[i+1] = tab[i] ;
        i -- ;
    }
}
void Ensemble::add (int elem)
{
    cout << "\nInsertion dans set de elem = " << elem << "\n" ;

    /// Etape 1 : trouver j, l'indice d'insertion de elem
    int j = trouverJ(elem);
    cout << "\t L\'indice d\'insertion est j = "<<j <<endl ;
    /// Etape 2 : decaler vers la droite toto.elem[j..n-1]
    decaleDroite(j,n) ;
    n ++ ; /// Pour besoin d'affichage
    cout << "\t Apres decalage a droite, set devient : " ;
    this->affiche2() ;
    /// Etape 3 : inserer elem et incrémenter la taille de toto
    tab[j] = elem ;
    /// n ++ ;
}
/** *****************************************************************************************************
 */

/** Remplace l’élément de la position pos par elem et
retourne l ’élément initiale de cette position
@pre
    * toto est un ensemble
    * 0 <= pos < toto.n
    * elem notin toto
@post
    this->tab reste inchangé sauf à la position pos où elem occupe
    la place de l'élément précédent this->tab[Pos]
@result
   this->tab[Pos]
*/
/** Division en sous-problèmes
SP1 : troujerJ, la position d'insertion de elem
SP2 : Décaler d'un pas vers la droite le sous-tableau tab[i..j]
SP3 : Décaler d'un pas vers la gauche le sous-tableau tab[i..j]
SP4 : insérer elem à la position pos
*/
/// SP1 : trouverJ est déjà implémentée
/// SP2 : decaleDroite(i, j) est déjà implémentée
/** SP3 : Décaler d'un pas vers la gauche le sous-tableau tab[i..j]
@pre
    0 <= a < b < NMAX
@post
    tous les éléments de this->tab[a..b] sont décalés d'un pas vers la gauche
@result
    -
*/
void Ensemble::decaleGauche(int a, int b)
{
    int i = (a == 0 ? 1 : a) ;
    while (i <= b)
    {
        tab[i-1] = tab[i] ;
        i ++ ;
    }
}
int Ensemble::set (int elem , int pos )
{
    /// Etape 1 : trouverJ, l'index d'insertion
    cout << "\nInsertion de " << elem << " dans set a la position " << pos << "\n" ;
    int j = trouverJ(elem) ;
    cout<< "\t avant décalage set = " ;
    this->affiche2() ;
    cout << "\t la position d\'insertion est j = " << j << "\n" ;

    /// Etape 2 : Decaler le sous-tableau tab(pos..j)
    int old = tab[pos] ; // sauvergarde l'élément à remplacer
    if (pos > j)
    {
        decaleDroite(j, pos-1) ;
        cout<< "\t apres decalage droite set = " ;
        this->affiche2() ;
        /// Etape 3 : inserer elem a la position pos
        tab[j] = elem ;
        cout << "\n" ;

        cout<< "\t apres insertion set = " ;
        this->affiche2() ;
        cout << "\n" ;
    }
    else
    {
        decaleGauche(pos+1, j ) ;
        cout<< "\t apres decalage gauche set = " ;
        this->affiche2() ;
        /// Etape 3 : insérer elem à la position pos
        tab[j-1] = elem ;
        cout << "\n" ;

        cout<< "\t apres insertion set = " ;
        this->affiche2() ;
        cout << "\n" ;
    }

    return old ;
}

/** Supprime l’élément de position pos et le renvoie ,
puis repositionne les autres éléments
@pre
    0 <= pos < n
@post
    l'élément this->tab[pos] de la position pos de toto est supprimé et les autres éléments sont repositonnés
@result
    retourne totoPos
*/
Ensemble Ensemble::remove (int pos ){}

/** Test de non appartenance à un ensemble
@pre
    toto est un ensemble
@post
    toto reste inchangé
@result
    return vrai si elem n'est pas dans toto, faux sinon
*/
bool Ensemble::notin(int elem) {}

/** Renvoie l’union des ensembles A et B
@pre
    A et B sont des ensembles
@post
    A et B restent inchangés
    C = A union B
@result
    -
*/
Ensemble Ensemble::unnion ( Ensemble B )
{
    Ensemble C ;
    int i = 0, j = 0, k = 0 ;
    while (i < n && j < B.n)
    {
        /// On classe chaque fois le plus petit de A et B dans C
        if (tab[i] < B.tab[j])
            /// Le plus petit élément des deux ensembles est A.set[i]
        {
            C.tab[k] = tab[i] ;
            k ++ ;
            i ++ ;
        }
        else if (tab[i] > B.tab[j])
            /// Le plus petit élément des deux ensembles est B.set[j]
        {
            C.tab[k] = B.tab[j] ;
            k ++ ;
            j ++ ;
        }
        else
            /// Le plus petit élément des deux ensembles est A.set[i] = B.set[j]
        {
            C.tab[k] = B.tab[j] ;
            k ++ ;
            j ++ ;
            i ++ ;
        }
    }

    /// On classe alors les éventuelles restes des deux ensembles A et B
    while (i < n)
        /// On classe d'abord l'éventuel reste de A
    {
        C.tab[k] = tab[i] ;
        k ++ ;
        i ++ ;
    }
    while (j < B.n)
        /// On classe ensuite l'éventuel reste de B
    {
        C.tab[k] = tab[j] ;
        k ++ ;
        j ++ ;
    }

    // Mise à jour du nombre d'éléments de C
    C.n = k ;
    return C;
}


Ensemble Ensemble::diff ( Ensemble B ) {}
/** Renvoie les é l é ments de A qui ne sont pas dans B */


/** Renvoie vrai si l’ensemble est vide
@pre
    toto est un ensemble
@post
    toto reste inchangé
@result
    return TRUE si toto.n == 0; FALSE sinon
*/
bool Ensemble::isEmpty ()
{
    // toto est vide quand sa taille est 0
    if (n == 0) return true ;
    return false ;
}

/**
 * @brief Ensemble::getFirst: renvoie le premier element de l'ensemble
 @pre
    -
 @post
    -
 * @return
    this->tab[0]/// retourne le premier element du tableau
 */

int Ensemble::getFirst()
{
    return tab[0];
}
/** Renvoie le premier élément de l’ensemble :
 * renvoie le dernier element de l'ensemble
 @pre
    -
 @post
    -
 * @return
    this->tab[n-1]/// retourne le dernier element du tableau
*/

int Ensemble::getLast ()
{
    return tab[n-1];
}

/** Renvoie le dernier élément de l’ensemble */

/** Mais aussi : addLast */






#include <iostream>
#include <cstdlib>

using namespace std;
/**
 * @brief The Cellule struct
 Structure cellule
 */
struct Cellule
{
    int val;
    Cellule * before;
    Cellule * next;
};

/**
 * @brief The Liste struct
 *Structure Liste
 */
struct Liste
{
    int taille;
    int id;
    Cellule * tete;
};

/**
  Initialise la liste
 * @brief init
 * @param toto
 * @param n
 @pre
       toto est une liste
       n est un  entier
 @post
        toto change,
        toto->taille=0;
        toto->id=n;
        toto->tete est crée
 @return
        -

 */

void init(Liste & toto, int n)
{

    toto.taille=0;
    toto.id=n;
    toto.tete= new Cellule;
    toto.tete->next=NULL;
    toto.tete->before=NULL;
}
/**
  Renvoie la taille de la liste
 * @brief taille
 * @param toto
 *@pre
        toto est une liste
 *@post
        toto ne change pas
 * @return
        toto.taille;
 */
int taille(Liste toto)
{
    if(&toto==NULL)
    {
        exit(EXIT_FAILURE);
    }
    return toto.taille;
}
/**
  ajoute un element au debut de la liste
 * @brief ajouteDebut
 * @param toto
 * @param valeur
 * @pre
        toto est une liste non NULL;
        valeur est un entier
 * @post
        toto->tete devient la nouvelle valeur
        la taille de toto est augmentée
 * @return
        -
==========================================================================================
                            STEPs
STEP1:
    verifier que Toto est non null;
STEP2:
    creer une nouvelle cellule et luiu affecter la valeur value
STEP3:
    linker la nouvelle cellule à toto
==========================================================================================

 */
void ajouteDebut(Liste * toto, int value)
{
    if(toto==NULL)
    {
        exit(EXIT_FAILURE);
    }
    Cellule* newcel= new Cellule;
    newcel->val=value;
    newcel->before=NULL;
    newcel->next=toto->tete->next;
    toto->taille++;
}

/**
  Ajoute à la fin de la liste
 * @brief ajouteFin
 * @param toto
 * @param value
 * @pre
        toto est une liste non nulle
        value est un entier
 * @post
        value est ajoutée à la fin de toto
        la taille de toto est augmentée de 1
 * @return
        -

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                    STEPs
STEP1:
    verifier que toto est non nulle
STEP2:
    creer une nouvelle cellule et inserer value
STEP3:
    utiliser un curseur pour atteindre la fin de la liste
STEP4:
    linker la nouvelle cellule
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

*/

void ajouteFin(Liste *toto, int value)
{
    if(&toto==NULL)
    {
        exit(EXIT_FAILURE);
    }
    Cellule *newcel=new Cellule;
    newcel->val=value;
    Cellule *cur=toto->tete;
    int i = 1 ;
    while (i < toto->taille)
    {
        /* code */
        cur = cur->next;
        i++;
    }
    cur->next=newcel;
    newcel->before=cur;
    newcel->next=NULL;
    toto->taille+=1;
    delete cur;
}

/**
  Ajoute value une position pos de la liste
 * @brief ajoutePosition
 * @param toto
 * @param pos
 * @param value
 * @pre
        toto est une liste non null
        1<=pos<=toto->taille+1
        value est un entier
   @post
        toto change en prenant value à pos
        toto est augmentée d'une valeur (toto->taille++)
   @return
        -
******************************************************************************************
                                    STEPs
STEP1:
        verifier que toto est non nulle && 1<=pos<=toto->taille+1
STEP2:
        creer un curseur pour parcourir la liste jusqu'à pos-1
STEP3:
        recuperer pos+1 dans une variable reste
STEP4:
        creer une cellule pour inserer value et linker avec la liste
******************************************************************************************
 */
void ajoutePosition(Liste * toto, int pos, int value)
{
    if(&toto==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(1<=pos && pos<=toto->taille+1)
    {
        Cellule * cur=toto->tete;
        int i=1;
        while(i<pos-1)
        {
            cur=cur->next;
            i++;
        }
        Cellule * reste=cur->next;
        Cellule * newcel=new Cellule;
        newcel->val=value;
        newcel->before=cur;
        newcel->next=reste;
        reste->before=newcel;
        toto->taille++;
        delete cur;
    }

}

/**
  Supprime le premier element de la liste
 * @brief supprimerDebut
 * @param toto
   @pre
        toto est une liste non null
        toto contient au moins un element
   @post
        toto perd son premier element
        toto->taille -=1
   @return
        -

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                                    STEPs
STEP1:
        verifier que la liste est non null et contient au moins un element
STEP2:
        recuperer le premier element dans une variable suppri;
STEP3:
        mettre le premier element de toto à toto->tete->next
STEP4:
        mettre le precedent du premier element à NULL
STEP5: supprimer la varible suppri
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
 */

void supprimerDebut(Liste * toto)
{
    if(&toto==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if (toto->tete != NULL)
    {
        Cellule *aSupprimer = toto->tete->next;
        toto->tete->next = toto->tete->next->next;
        delete aSupprimer;
        toto->taille-=1;
    }

}

/**
  Supprime le dernier element de la liste
 * @brief supprimeFin
 * @param toto
   @pre
        toto est une liste non nulle
        toto contient au moins un element
   @post
        toto perd son dernier element
        toto->taille-=1
   @return
        -
------------------------------------------------------------------------------------------
                                STEPs
 STEP0:
     verifier que la liste est non nulle et qu'elle conyient au moins un element;
 STEP1:
     creer un curseur pour atteindre la fin de la listeen s'arretant à la taille-2;
 STEP2:
     recuperer le derneir element de la liste dans une variable suppri;
 STEP3:
     linker l'avant dernier element à null
 STEP4:
     supprimer le dernier element mis dans suppri;
------------------------------------------------------------------------------------------
 */

void supprimerFin(Liste * toto)
{
    if(&toto==NULL)
    {
        exit(EXIT_FAILURE);
    }
    if(toto->taille>0)
    {
        Cellule * cur=toto->tete;
        int i=0;
        while(i<toto->taille-2)
        {
            cur=cur->next;
            i++;
        }
        Cellule * suppri=cur->next;
        cur->next=NULL;
        delete suppri;
        toto->taille--;
    }
}

/**
  @pre
    toto est une liste non nulle
  @post
    toto ne change pas
  @return
    -
 * @brief affiche
 * @param toto
 */

void affiche(Liste toto)
{
    if (&toto == NULL)
    {
        exit(EXIT_FAILURE);
    }

    Cellule *actuel = toto.tete->next;
    while (actuel != NULL)
    {
        cout<<actuel->val<<"-> ";
        actuel = actuel->next;

    }
    cout<<"NULL\n";
    delete actuel;
}

int main()
{
  Liste * moi;
  init(*moi,1);
  affiche(*moi);
  cout<<endl;
  ajouteFin(moi, 4);
  ajoutePosition(moi, 0,1);
 /// ajouteDebut(moi, 4); revoir la fonction ajoute debut car il n'ajoute pas au debut
  affiche(*moi);

    return EXIT_SUCCESS;
}

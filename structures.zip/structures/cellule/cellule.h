#ifndef CELLULE_H
#define CELLULE_H
#include<iostream>
 template <typename E>
class Cellule
{
    public:
        Cellule();
        Cellule(E valeur);
        Cellule(E valeur, Cellule * suive);
        virtual ~Cellule();
    protected:
        E Val();
        Cellule<E> *Suivant();
        void setVal(E valeur);
        void setSuivant(Cellule * suive);
    private:
        E val;
        Cellule * suivant;

};



#endif // CELLULE_H

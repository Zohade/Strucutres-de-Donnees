#include "cellule.h"
#include <iostream>
#include<cstdlib>
using namespace std;

template <typename E>

Cellule<E>::Cellule()
{
    val=0;
    suivant=NULL;
}
template <typename E>

Cellule<E>::Cellule(E valeur)
{
    val= valeur;
    suivant =NULL;
}
template <typename E>
Cellule<E>::Cellule(E valeur, Cellule * suive)
{
    val= valeur;
    suivant =suive;
}
template <typename E>

Cellule<E>::~Cellule()
{
    std::cout<<"Destruction d\'un element";
}
template <typename E>

E Cellule<E>::Val()
{
    return val;
}
template <typename E>

Cellule<E> * Cellule<E>::Suivant()
{
    return suivant;
}
template <typename E>

void Cellule<E>::setVal(E valeur)
{
  val=valeur;
}
template <typename E>

void Cellule<E>::setSuivant(Cellule * suive)
{
    suivant=suive;
}

int main()
{
    Cellule<int> cel(6);
    cout<<cel.Val();
    return EXIT_SUCCESS;
}







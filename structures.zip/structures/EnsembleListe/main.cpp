#include <iostream>
#include<cstdlib>

using namespace std;

struct Ensemble
{
    int n;
    Ensemble * suivant;
    Ensemble * precedent;
};

struct Listes
{
    int nbre_elem;
    Ensemble * premier;
};
/** ************************************************************************************************
 *INITIALISATION D'UNE LISTES
  @pre
    -
  @post
    liste et ens doit pas etre null.
  @return
    liste

   ================================================
   Sous probleme
   SP1: Allocation dynamiqe d'espace avec la fonction  malloc pour la liste et pour son premier element
   SP2: Controler de l'execution de l'allocation
   SP3 :
        - initialiser le nombre du premeir element à 0;
        - son suivant à null;
        - le nombre d'element de la liste à 0;
        - et le premier element de la liste à ens;


 */
Listes * initialisation()
{
    /// SP1
    Listes *liste= (Listes*) malloc(sizeof(*liste));
    Ensemble * ens= (Ensemble*) malloc(sizeof(*ens));
    /// SP2
    if(liste==NULL || ens==NULL)
    {
        exit(EXIT_FAILURE);
    }
    /// SP3
    ens->n=0;
    ens->suivant=NULL;
    liste->nbre_elem=0;
    liste->premier=ens;
    return liste;
}
/**
  fonction d'insertion qui ajoute l'element au debut

 * @brief insertion
 * @param liste
 * @param nbre
 @pre
    liste est une Liste,
    nbre estt un entier
 @post
    nouveau est crée;
    nouveau et liste doivent etre diferents de NULL
 @return -

 ==================================================================================
 SP1: creation du nouvel element
 SP2 : verification de nouveau et  liste différents de null
 SP3 : initialisation de :
    - entier de nouveau à nbre;
    - mettre son element suivant au premier element de l'ensemble
    - mettre le premier element de liste au nouveau
    - ajouter +1 au nbre d'element de la liste;

 */

void insertion(Listes* liste, int nbre)
{
    Ensemble* nouveau= (Ensemble*) malloc(sizeof(*nouveau));
    if(liste==NULL || nouveau==NULL)
    {
        exit(EXIT_FAILURE);
    }
    nouveau->n=nbre;
    nouveau->suivant=liste->premier;
    liste->premier=nouveau;
    liste->nbre_elem+=1;
}

/**
 * supprimer le premier element de la Liste
   @pre
        liste est une Liste non vide.
        le premier element doit etre non null
   @post
        le premier element à changer et passe à son suivant;
        le nombre d'element de la liste est diminuer d'un
   @return -

   ===============================================================================
   SP1: Verifier que la liste est non vide et le premier element no plus
   SP2:
 */
void supprimer(Liste* liste)
{


}


int main()
{

    return EXIT_SUCCESS;
}
